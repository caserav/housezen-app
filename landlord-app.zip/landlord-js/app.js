document.addEventListener('DOMContentLoaded', async () => {
    setupEventListeners();
    await initAuth();
});
